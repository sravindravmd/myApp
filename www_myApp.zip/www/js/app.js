// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'ionic-material', 'ionMdInput','starter.services'])
/*angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])*/
.run(function($ionicPlatform) {
    $ionicPlatform.ready(function() {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
    });
})

/*.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

    // Turn off caching for demo simplicity's sake
    $ionicConfigProvider.views.maxCache(0);*/
    .config(function($stateProvider, $urlRouterProvider) {

    /*
    // Turn off back button text
    $ionicConfigProvider.backButton.previousTitleText(false);
    */

    $stateProvider

        .state('app', {
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
    })

    /*.state('app.activity', {
        url: '/activity',
        views: {
            'menuContent': {
                templateUrl: 'templates/activity.html',
                controller: 'ActivityCtrl'
            },
            'fabContent': {
                template: '<button id="fab-activity" class="button button-fab button-fab-top-right expanded button-energized-900 flap"><i class="icon ion-paper-airplane"></i></button>',
                controller: function ($timeout) {
                    $timeout(function () {
                        document.getElementById('fab-activity').classList.toggle('on');
                    }, 200);
                }
            }
        }
    })

    .state('app.friends', {
        url: '/friends',
        views: {
            'menuContent': {
                templateUrl: 'templates/friends.html',
                controller: 'FriendsCtrl'
            },
            'fabContent': {
                template: '<button id="fab-friends" class="button button-fab button-fab-top-left expanded button-energized-900 spin"><i class="icon ion-chatbubbles"></i></button>',
                controller: function ($timeout) {
                    $timeout(function () {
                        document.getElementById('fab-friends').classList.toggle('on');
                    }, 900);
                }
            }
        }
    })

    .state('app.gallery', {
        url: '/gallery',
        views: {
            'menuContent': {
                templateUrl: 'templates/gallery.html',
                controller: 'GalleryCtrl'
            },
            'fabContent': {
                template: '<button id="fab-gallery" class="button button-fab button-fab-top-right expanded button-energized-900 drop"><i class="icon ion-heart"></i></button>',
                controller: function ($timeout) {
                    /!*$timeout(function () {
                        document.getElementById('fab-gallery').classList.toggle('on');
                    }, 600);*!/
                }
            }
        }
    })*/

        .state('app.registration', {
            url: '/registration',
            views: {
                'menuContent': {
                    templateUrl: 'templates/registration.html',
                    controller: 'RegCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                       /* $timeout(function () {
                            document.getElementById('fab-gallery').classList.toggle('on');
                        }, 600);*/
                    }
                }
            }
        })
        .state('app.home', {
            url: '/home',
            views: {
                'menuContent': {
                    templateUrl: 'templates/home.html',
                    controller: 'HomeCtrl'
                },
                'fabContent': {
                    template: ''
                }
            }
        })

    .state('app.login', {
        url: '/login',
        views: {
            'menuContent': {
                templateUrl: 'templates/login.html',
                controller: 'LoginCtrl'
            }

        }
    })



    /*.state('app.profile', {
        url: '/profile',
        views: {
            'menuContent': {
                templateUrl: 'templates/profile.html',
                controller: 'ProfileCtrl'
            },
            'fabContent': {
                template: '<button id="fab-profile" class="button button-fab button-fab-bottom-right button-energized-900"><i class="icon ion-plus"></i></button>',
                controller: function ($timeout) {
                    /!*$timeout(function () {
                        document.getElementById('fab-profile').classList.toggle('on');
                    }, 800);*!/
                }
            }
        }
    })*/

        .state('app.distributor_login', {
            url: '/distributor_login',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_login.html',
                    controller: 'DistLoginCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_Reg', {
            url: '/distributor_Reg',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_Reg.html',
                    controller: 'DistRegCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.retailer_Reg', {
            url: '/retailer_Reg',
            views: {
                'menuContent': {
                    templateUrl: 'templates/retailer_Reg.html',
                    controller: 'RetailRegCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_reset_pass', {
            url: '/distributor_reset_pass',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_reset_pass.html',
                    controller: 'DistResetPassCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_home', {
            url: '/distributor_home',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_home.html',
                    controller: 'DistHomeCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_my_profile', {
            url: '/distributor_my_profile',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_my_profile.html',
                    controller: 'DistProfileCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_product_detail', {
            url: '/distributor_product_detail',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_product_detail.html',
                    controller: 'DistProductDetailCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_order', {
            url: '/distributor_order',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_order.html',
                    controller: 'DistOrderCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_create_order', {
            url: '/distributor_create_order',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_create_order.html',
                    controller: 'CreateDistOrderCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_order_detail', {
            url: '/distributor_order_detail',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_order_detail.html',
                    controller: 'DistOrderDetailCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.target_os_p', {
            url: '/target_os_p',
            views: {
                'menuContent': {
                    templateUrl: 'templates/target_os_p.html',
                    controller: 'TargetOSCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.channel_partner', {
            url: '/channel_partner',
            views: {
                'menuContent': {
                    templateUrl: 'templates/channel_partner.html',
                    controller: 'ChannelPartnerCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_notification', {
            url: '/distributor_notification',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_notification.html',
                    controller: 'DistNotificationCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.change_password', {
            url: '/change_password',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_change_password.html',
                    controller: 'ChangePassCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.news', {
            url: '/news',
            views: {
                'menuContent': {
                    templateUrl: 'templates/news.html',
                    controller: 'NewsCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.customer_feedback', {
            url: '/customer_feedback',
            views: {
                'menuContent': {
                    templateUrl: 'templates/customer_feedback.html',
                    controller: 'CustomerFeedbackCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.retailer_home', {
            url: '/retailer_home',
            views: {
                'menuContent': {
                    templateUrl: 'templates/retailer_home.html',
                    controller: 'RetailerHomeCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.retailer_my_profile', {
            url: '/retailer_my_profile',
            views: {
                'menuContent': {
                    templateUrl: 'templates/retailer_my_profile.html',
                    controller: 'RetailerProfileCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.forgot_password', {
            url: '/forgot_password',
            views: {
                'menuContent': {
                    templateUrl: 'templates/forgot_password.html',
                    controller: 'ForgotPasswordCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_brand_stories', {
            url: '/distributor_brand_stories',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_brand_stories.html',
                    controller: 'DistBrandStoriesCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.distributor_feedback_query', {
            url: '/distributor_feedback_query',
            views: {
                'menuContent': {
                    templateUrl: 'templates/distributor_feedback_query.html',
                    controller: 'DistFeedbackQueryCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.retailer_product_detail', {
            url: '/retailer_product_detail',
            views: {
                'menuContent': {
                    templateUrl: 'templates/retailer_product_detail.html',
                    controller: 'RetailerProductDetailCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

        .state('app.retailer_create_order', {
            url: '/retailer_product_detail',
            views: {
                'menuContent': {
                    templateUrl: 'templates/retailer_create_order.html',
                    controller: 'RetailerCreatteCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*/
                    }
                }
            }
        })

      .state('app.customer_login', {
        url: '/customer_login',
        views: {
          'menuContent': {
            templateUrl: 'templates/customer_login.html',
            controller: 'customerLoginCtrl'
          }
        }
      })

      .state('app.retailer_login', {
        url: '/retailer_login',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_login.html',
            controller: 'RetailerLoginCtrl'
          }
        }
      })

      .state('app.retailer_order', {
        url: '/retailer_order',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_order.html',
            controller: 'RetailerOrderCtrl'
          }
        }
      })

      .state('app.retailer_notification', {
        url: '/retailer_notification',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_notification.html',
            controller: 'retailerNotificationCtrl'
          }
        }
      })

      .state('app.retailer_brand_stories', {
        url: '/retailer_brand_stories',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_brand_stories.html',
            controller: 'retailerBrandStoriesCtrl'
          }
        }
      })

      .state('app.retailer_feedback_query', {
        url: '/retailer_feedback_query',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_feedback_query.html',
            controller: 'retailerFeedbackQueryCtrl'
          }
        }
      })

      .state('app.retailer_change_password', {
        url: '/retailer_change_password',
        views: {
          'menuContent': {
            templateUrl: 'templates/retailer_change_password.html',
            controller: 'retailerChangePasswordCtrl'
          }
        }
      })
        /*.state('app.radio', {
            url: '/radio',
            views: {
                'menuContent': {
                    templateUrl: 'templates/radio.html',
                    controller: 'RadioCtrl'
                },
                'fabContent': {
                    template: '',
                    controller: function ($timeout) {
                        /!* $timeout(function () {
                         document.getElementById('fab-gallery').classList.toggle('on');
                         }, 600);*!/
                    }
                }
            }
        })*/
    ;

    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/home');
});
